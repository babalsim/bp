Pre viac testovacich videi treba navstivit github repozitar k tejto praci na https://github.com/babalsim/bp

Ako navod na pouzivanie aplikacie moze sluzit kapitola implementacia v bakalarskej praci, pricom navod na instalaciu vsetkych potrebnych kniznic je tiez na githube

Vsetky potrebne kniznice su napisane taktiez v komentaroch v zdrojovom subore main.py